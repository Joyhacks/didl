// Put your product image in the same folder as these files and name it: product.webp
// (Or update TEXTURE_URL below)

const TEXTURE_URL = "./product.webp";

document.getElementById("year").textContent = new Date().getFullYear();

// --- Interactive microcopy
(function initInteractiveText(){
  const el = document.getElementById("swapText");
  if (!el) return;

  const words = (el.dataset.words || "").split(",").map(s => s.trim()).filter(Boolean);
  if (!words.length) return;

  let idx = 0;
  let phase = "type"; // type -> hold -> erase
  let char = 0;
  let hold = 0;

  const typeSpeed = 34;
  const eraseSpeed = 22;
  const holdTime = 45; // frames

  function tick(){
    const word = words[idx];

    if (phase === "type") {
      char = Math.min(word.length, char + 1);
      el.textContent = word.slice(0, char);
      if (char >= word.length) {
        phase = "hold";
        hold = 0;
      }
      setTimeout(tick, typeSpeed);
      return;
    }

    if (phase === "hold") {
      hold++;
      if (hold > holdTime) phase = "erase";
      setTimeout(tick, 22);
      return;
    }

    // erase
    char = Math.max(0, char - 1);
    el.textContent = word.slice(0, char);
    if (char <= 0) {
      idx = (idx + 1) % words.length;
      phase = "type";
    }
    setTimeout(tick, eraseSpeed);
  }

  tick();
})();

(function initWhyVelvet(){
  const btn = document.getElementById("whyBtn");
  const note = document.getElementById("whyNote");
  if (!btn || !note) return;

  const messages = [
    "Designed for comfort-first use and everyday simplicity.",
    "Minimal controls, premium materials, and discreet delivery.",
    "Quiet operation with easy cleaning and storage guidance.",
    "A modern, private checkout experience — no clutter, no noise."
  ];

  let i = 0;
  btn.addEventListener("click", () => {
    note.textContent = messages[i];
    i = (i + 1) % messages.length;
  });
})();

// --- Reveal on scroll
(function initReveal(){
  const sections = document.querySelectorAll(".reveal");
  if (!sections.length) return;

  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) e.target.classList.add("show");
    });
  }, { threshold: 0.12 });

  sections.forEach(s => io.observe(s));
})();

// --- Three.js setup (guard in case CDN fails)
if (!window.THREE) {
  console.warn("Three.js not loaded. Ensure the CDN is reachable.");
} else {
  const canvas = document.getElementById("product3d");

  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: true,
    alpha: true,
    powerPreference: "high-performance"
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.outputColorSpace = THREE.SRGBColorSpace;

  const scene = new THREE.Scene();

  const camera = new THREE.PerspectiveCamera(38, 1, 0.1, 100);
  camera.position.set(0, 0, 6.2);

  const ambient = new THREE.AmbientLight(0xffffff, 0.9);
  scene.add(ambient);

  const key = new THREE.DirectionalLight(0xffffff, 1.1);
  key.position.set(3, 4, 6);
  scene.add(key);

  const rim = new THREE.DirectionalLight(0xff7fbf, 0.65);
  rim.position.set(-5, 1.5, -2);
  scene.add(rim);

  const group = new THREE.Group();
  scene.add(group);

  // Glow behind the product
  const glowGeo = new THREE.PlaneGeometry(5.2, 5.2);
  const glowMat = new THREE.MeshBasicMaterial({
    color: 0xff4fa7,
    transparent: true,
    opacity: 0.12,
    blending: THREE.AdditiveBlending,
    depthWrite: false
  });
  const glow = new THREE.Mesh(glowGeo, glowMat);
  glow.position.z = -0.2;
  group.add(glow);

  // Product plane
  const loader = new THREE.TextureLoader();
  let productMesh = null;

  loader.load(
    TEXTURE_URL,
    (tex) => {
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.anisotropy = Math.min(renderer.capabilities.getMaxAnisotropy(), 8);

      const imgW = (tex.image && tex.image.width) ? tex.image.width : 1024;
      const imgH = (tex.image && tex.image.height) ? tex.image.height : 1024;
      const aspect = imgW / imgH;

      const height = 4.6;
      const width = height * aspect;

      const geo = new THREE.PlaneGeometry(width, height, 64, 64);
      const mat = new THREE.MeshStandardMaterial({
        map: tex,
        transparent: true,
        roughness: 0.85,
        metalness: 0.1
      });

      productMesh = new THREE.Mesh(geo, mat);
      productMesh.position.z = 0.22;
      group.add(productMesh);

      // subtle depth lift
      const pos = geo.attributes.position;
      for (let i = 0; i < pos.count; i++) {
        const x = pos.getX(i);
        const y = pos.getY(i);
        const edge = Math.min(
          Math.abs(x) / (width / 2),
          Math.abs(y) / (height / 2)
        );
        const lift = (1 - edge) * 0.06;
        pos.setZ(i, pos.getZ(i) + lift);
      }
      pos.needsUpdate = true;
      geo.computeVertexNormals();
    },
    undefined,
    (err) => {
      console.warn("Texture failed to load. Ensure product.webp exists next to index.html", err);
    }
  );

  // Decorative particles
  const particles = new THREE.Group();
  scene.add(particles);

  const pCount = 80;
  const pGeo = new THREE.SphereGeometry(0.03, 10, 10);
  const pMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.35 });

  for (let i = 0; i < pCount; i++) {
    const p = new THREE.Mesh(pGeo, pMat);
    const r = 2.8 + Math.random() * 1.9;
    const a = Math.random() * Math.PI * 2;
    const y = (Math.random() - 0.5) * 3.0;
    p.position.set(Math.cos(a) * r, y, (Math.sin(a) * r) - 0.8);
    p.userData = {
      baseY: p.position.y,
      speed: 0.35 + Math.random() * 0.85,
      phase: Math.random() * Math.PI * 2
    };
    particles.add(p);
  }

  // Interaction
  let targetRX = 0;
  let targetRY = 0;
  let isDown = false;
  let lastX = 0;
  let lastY = 0;

  function setTargetsFromNormalized(nx, ny) {
    targetRY = nx * 0.55;
    targetRX = ny * 0.28;
  }

  function pointerToNorm(e) {
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    const y = (e.clientY - rect.top) / rect.height;
    const nx = (x - 0.5) * 2;
    const ny = (y - 0.5) * 2;
    return { nx, ny };
  }

  canvas.addEventListener("pointerdown", (e) => {
    isDown = true;
    lastX = e.clientX;
    lastY = e.clientY;
    try { canvas.setPointerCapture(e.pointerId); } catch(_) {}
  }, { passive: true });

  canvas.addEventListener("pointerup", (e) => {
    isDown = false;
    try { canvas.releasePointerCapture(e.pointerId); } catch(_) {}
  }, { passive: true });

  canvas.addEventListener("pointermove", (e) => {
    if (isDown) {
      const dx = (e.clientX - lastX) / 260;
      const dy = (e.clientY - lastY) / 260;
      lastX = e.clientX;
      lastY = e.clientY;
      targetRY += dx;
      targetRX += dy;
      targetRX = Math.max(-0.55, Math.min(0.55, targetRX));
    } else {
      const { nx, ny } = pointerToNorm(e);
      setTargetsFromNormalized(nx, ny);
    }
  }, { passive: true });

  canvas.addEventListener("mouseleave", () => {
    targetRX = 0;
    targetRY = 0;
  });

  // Resize
  function resize() {
    const rect = canvas.getBoundingClientRect();
    const w = Math.max(1, Math.floor(rect.width));
    const h = Math.max(1, Math.floor(rect.height));
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
  window.addEventListener("resize", resize, { passive: true });
  resize();

  // Render loop
  const clock = new THREE.Clock();

  function animate() {
    const t = clock.getElapsedTime();

    // smooth rotate toward target
    group.rotation.y += (targetRY - group.rotation.y) * 0.06;
    group.rotation.x += (targetRX - group.rotation.x) * 0.06;

    // idle float + slow spin
    group.position.y = Math.sin(t * 1.1) * 0.08;
    group.rotation.z = Math.sin(t * 0.7) * 0.03;
    group.rotation.y += 0.0025;

    // particle drift
    particles.children.forEach((p) => {
      const u = p.userData;
      p.position.y = u.baseY + Math.sin(t * u.speed + u.phase) * 0.12;
    });

    // pulse glow
    glow.material.opacity = 0.10 + (Math.sin(t * 1.6) * 0.02 + 0.02);

    renderer.render(scene, camera);
    requestAnimationFrame(animate);
  }
  animate();
}
